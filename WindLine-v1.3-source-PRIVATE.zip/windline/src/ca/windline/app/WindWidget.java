package ca.windline.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

/** Home-screen widget: current wind and sail size at your chosen spot. */
public class WindWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        Alerts.updateWidgets(c);
        Alerts.schedule(c);
        Alerts.runAsync(c.getApplicationContext(), null);
    }
}
