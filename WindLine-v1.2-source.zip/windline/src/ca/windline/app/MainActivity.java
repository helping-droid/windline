package ca.windline.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** WindLine: a native shell around the bundled forecast app (assets/index.html). */
public class MainActivity extends Activity {

    private WebView web;
    private GeolocationPermissions.Callback pendingGeo;
    private String pendingOrigin;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#07131F"));
        w.setNavigationBarColor(Color.parseColor("#0B1A2A"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#07131F"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return openExternal(url);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    cb.invoke(origin, true, true);
                } else {
                    pendingGeo = cb;
                    pendingOrigin = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, 7);
                }
            }
        });

        if (state != null) web.restoreState(state);
        else web.loadUrl("file:///android_asset/index.html");
    }

    private boolean openExternal(String url) {
        if (url.startsWith("file:///android_asset/")) return false;
        try {
            Intent i;
            if (url.startsWith("intent:")) i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
            else i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            // nothing can open it
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == 7 && pendingGeo != null) {
            boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
            pendingGeo.invoke(pendingOrigin, ok, ok);
            pendingGeo = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.appBack ? appBack() : false", new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String value) {
                if (!"true".equals(value)) finishBack();
            }
        });
    }

    private void finishBack() { super.onBackPressed(); }

    /** Finds an installed app whose name contains the keyword (e.g. "Windguru"). */
    private String findPackage(String keyword) {
        String k = keyword.toLowerCase();
        PackageManager pm = getPackageManager();
        for (android.content.pm.ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue;
            String label = String.valueOf(pm.getApplicationLabel(ai)).toLowerCase();
            if (label.contains(k) || ai.packageName.toLowerCase().contains(k.replace(" ", ""))) return ai.packageName;
        }
        return null;
    }

    /** Small bridge so the web app can open other apps and know it is inside the Android shell. */
    public class Bridge {
        @JavascriptInterface
        public void open(final String url) {
            runOnUiThread(new Runnable() { public void run() { openExternal(url); } });
        }
        /** Opens the installed app matching the keyword, otherwise the web page. */
        @JavascriptInterface
        public void openApp(final String keyword, final String fallbackUrl) {
            runOnUiThread(new Runnable() { public void run() {
                String pkg = findPackage(keyword);
                Intent i = pkg == null ? null : getPackageManager().getLaunchIntentForPackage(pkg);
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } else {
                    openExternal(fallbackUrl);
                }
            } });
        }
        @JavascriptInterface
        public boolean hasApp(String keyword) {
            return findPackage(keyword) != null;
        }
        @JavascriptInterface
        public void openCam(final String url, final String title, final String by) {
            runOnUiThread(new Runnable() { public void run() {
                Intent i = new Intent(MainActivity.this, CamActivity.class);
                i.putExtra("url", url); i.putExtra("title", title); i.putExtra("by", by);
                startActivity(i);
            } });
        }
        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(new Runnable() { public void run() {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Share conditions"));
            } });
        }
        @JavascriptInterface
        public void copy(String text) {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("WindLine", text));
        }
        @JavascriptInterface
        public String version() { return "1.2"; }
    }
}
