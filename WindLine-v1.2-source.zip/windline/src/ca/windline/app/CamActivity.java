package ca.windline.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** Full-screen in-app webcam viewer: loads any cam page (YouTube, earthTV, city cams…) inside WindLine. */
public class CamActivity extends Activity {

    private WebView web;
    private FrameLayout fullscreen;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        final String url = getIntent().getStringExtra("url");
        String title = getIntent().getStringExtra("title");
        String by = getIntent().getStringExtra("by");
        getWindow().setStatusBarColor(Color.parseColor("#07131F"));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#07131F"));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        // Top bar: close · title · open in browser
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(8), dp(8));
        bar.setBackgroundColor(Color.parseColor("#0B1A2A"));

        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setTextSize(20);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { finish(); } });
        bar.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(title == null ? "Webcam" : title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setSingleLine(true);
        TextView s = new TextView(this);
        s.setText((by == null ? "" : by + " · ") + "live view");
        s.setTextColor(Color.parseColor("#2EE6C5"));
        s.setTextSize(12);
        tcol.addView(t);
        tcol.addView(s);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = dp(6);
        bar.addView(tcol, tp);

        TextView ext = new TextView(this);
        ext.setText("Open ↗");
        ext.setTextColor(Color.parseColor("#9DB4C8"));
        ext.setTextSize(13);
        ext.setPadding(dp(10), dp(8), dp(10), dp(8));
        ext.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(web.getUrl() != null ? web.getUrl() : url))); } catch (Exception e) { }
        } });
        bar.addView(ext);
        col.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        final ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        col.addView(pb, new LinearLayout.LayoutParams(-1, dp(3)));

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String u) {
                if (u.startsWith("http://") || u.startsWith("https://")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                pb.setProgress(p);
                pb.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                customView = view; customCb = cb;
                fullscreen.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreen.setVisibility(View.VISIBLE);
            }
            @Override
            public void onHideCustomView() {
                if (customView != null) fullscreen.removeView(customView);
                fullscreen.setVisibility(View.GONE);
                customView = null;
                if (customCb != null) customCb.onCustomViewHidden();
            }
        });
        col.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));

        fullscreen = new FrameLayout(this);
        fullscreen.setBackgroundColor(Color.BLACK);
        fullscreen.setVisibility(View.GONE);
        root.addView(fullscreen, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        web.loadUrl(url);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { onHideFull(); return; }
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    private void onHideFull() {
        if (customView != null) fullscreen.removeView(customView);
        fullscreen.setVisibility(View.GONE);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.loadUrl("about:blank"); web.destroy(); }
        super.onDestroy();
    }
}
