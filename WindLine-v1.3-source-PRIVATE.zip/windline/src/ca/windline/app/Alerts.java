package ca.windline.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.SystemClock;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Background engine: every few hours fetches the forecast for the user's alert spots,
 * posts a notification when a rule matches (replacing iGetWind-style alerts),
 * and refreshes the home-screen widget.
 */
public class Alerts {

    static final String PREFS = "windline";
    static final String CH = "wind_alerts";
    static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    static final String[] DIRS16 = {"N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"};

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static JSONObject config(Context c) {
        try { return new JSONObject(prefs(c).getString("cfg", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    /** Schedule (or cancel) the repeating background check. */
    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, new Intent(c, AlertReceiver.class).setAction("ca.windline.CHECK"),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        JSONObject cfg = config(c);
        boolean any = hasActiveAlerts(cfg) || cfg.has("widget");
        if (!any) return;
        long every = cfg.optInt("everyHours", 3) * AlarmManager.INTERVAL_HOUR;
        am.setInexactRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 60_000L, every, pi);
    }

    static boolean hasActiveAlerts(JSONObject cfg) {
        JSONArray a = cfg.optJSONArray("alerts");
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) if (a.optJSONObject(i) != null && a.optJSONObject(i).optBoolean("on", true)) return true;
        return false;
    }

    static void runAsync(final Context c, final Runnable done) {
        new Thread(new Runnable() { public void run() {
            try { Alerts.run(c); } catch (Throwable t) { /* best effort */ }
            if (done != null) done.run();
        } }).start();
    }

    static String get(String u) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(u).openConnection();
        h.setConnectTimeout(15000); h.setReadTimeout(15000);
        h.setRequestProperty("User-Agent", "WindLine-Android");
        BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder(); String l;
        while ((l = r.readLine()) != null) sb.append(l);
        r.close();
        return sb.toString();
    }

    static JSONObject forecast(double lat, double lon) throws Exception {
        String u = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                + "&hourly=wind_speed_10m,wind_gusts_10m,wind_direction_10m,is_day"
                + "&current=wind_speed_10m,wind_gusts_10m,wind_direction_10m,temperature_2m"
                + "&wind_speed_unit=kn&timezone=auto&forecast_days=4";
        return new JSONObject(get(u));
    }

    static double sail(JSONObject cfg, double w, double g) {
        double kg = cfg.optDouble("kg", 80);
        double eff = w + 0.25 * Math.max(0, g - w);
        double s = 1.34 * kg / Math.max(eff, 6) * cfg.optDouble("styleF", 1.0);
        s = Math.max(3.0, Math.min(cfg.optDouble("maxSail", 10.0), s));
        JSONArray q = cfg.optJSONArray("sails");
        if (q != null && q.length() > 0) {
            double best = q.optDouble(0);
            for (int i = 0; i < q.length(); i++) if (Math.abs(q.optDouble(i) - s) < Math.abs(best - s)) best = q.optDouble(i);
            return best;
        }
        return Math.round(s * 10) / 10.0;
    }

    static String unitLabel(JSONObject cfg) {
        String u = cfg.optString("unit", "kn");
        return u.equals("kmh") ? "km/h" : u.equals("ms") ? "m/s" : u.equals("mph") ? "mph" : "kn";
    }
    static String wv(JSONObject cfg, double kn) {
        String u = cfg.optString("unit", "kn");
        double f = u.equals("kmh") ? 1.852 : u.equals("ms") ? 0.514444 : u.equals("mph") ? 1.15078 : 1;
        double v = kn * f;
        return u.equals("ms") ? String.valueOf(Math.round(v * 10) / 10.0) : String.valueOf(Math.round(v));
    }
    static String dir16(double d) { return DIRS16[(int) Math.round(((d % 360) + 360) % 360 / 22.5) % 16]; }
    static String hourLabel(int h) { return h == 0 ? "12am" : h < 12 ? h + "am" : h == 12 ? "12pm" : (h - 12) + "pm"; }

    static void run(Context c) throws Exception {
        JSONObject cfg = config(c);
        // ---- widget ----
        JSONObject wsp = cfg.optJSONObject("widget");
        if (wsp != null) {
            try {
                JSONObject f = forecast(wsp.getDouble("lat"), wsp.getDouble("lon"));
                JSONObject cur = f.getJSONObject("current");
                double w = cur.optDouble("wind_speed_10m", 0), g = cur.optDouble("wind_gusts_10m", w), d = cur.optDouble("wind_direction_10m", 0);
                // next good hour today
                String next = nextWindow(cfg, f, cfg.optDouble("minWind", 12), 99, null, 1);
                JSONObject wd = new JSONObject();
                wd.put("name", wsp.optString("name"));
                wd.put("wind", wv(cfg, w)); wd.put("unit", unitLabel(cfg));
                wd.put("kn", w);
                wd.put("detail", "Gusts " + wv(cfg, g) + " · " + dir16(d));
                wd.put("gear", w >= cfg.optDouble("minWind", 12) - 3 ? "Rig " + sail(cfg, w, g) + " m²" : (next != null ? "Next: " + next : "Light"));
                wd.put("at", System.currentTimeMillis());
                prefs(c).edit().putString("widgetData", wd.toString()).apply();
            } catch (Exception e) { /* keep last */ }
            updateWidgets(c);
        }
        // ---- alerts ----
        JSONArray rules = cfg.optJSONArray("alerts");
        if (rules == null) return;
        SharedPreferences p = prefs(c);
        String sent = p.getString("sent", "");
        for (int i = 0; i < rules.length(); i++) {
            JSONObject r = rules.optJSONObject(i);
            if (r == null || !r.optBoolean("on", true)) continue;
            try {
                JSONObject f = forecast(r.getDouble("lat"), r.getDouble("lon"));
                String[] key = new String[1];
                String win = nextWindow(cfg, f, r.optDouble("min", 14), r.optDouble("max", 35), r.optJSONArray("dirs"), r.optInt("days", 3), key, r);
                if (win == null) continue;
                String k = r.optString("id") + "@" + key[0];
                if (sent.contains("|" + k + "|")) continue;
                notify(c, r.optInt("nid", 100 + i), r.optString("name", "Wind alert"), win);
                sent = ("|" + k + "|" + sent);
                if (sent.length() > 3000) sent = sent.substring(0, 3000);
            } catch (Exception e) { /* skip this rule */ }
        }
        p.edit().putString("sent", sent).apply();
    }

    static String nextWindow(JSONObject cfg, JSONObject f, double min, double max, JSONArray dirs, int days) throws Exception {
        return nextWindow(cfg, f, min, max, dirs, days, new String[1], null);
    }

    /** Finds the first daylight run of >= 2 hours matching the rule; returns a human description. */
    static String nextWindow(JSONObject cfg, JSONObject f, double min, double max, JSONArray dirs, int days, String[] keyOut, JSONObject rule) throws Exception {
        JSONObject h = f.getJSONObject("hourly");
        JSONArray t = h.getJSONArray("time"), ws = h.getJSONArray("wind_speed_10m"), wg = h.getJSONArray("wind_gusts_10m"),
                wd = h.getJSONArray("wind_direction_10m"), day = h.getJSONArray("is_day");
        int off = f.optInt("utc_offset_seconds", 0);
        String nowLocal = new SimpleDateFormat("yyyy-MM-dd'T'HH", Locale.US) {{ setTimeZone(java.util.TimeZone.getTimeZone("UTC")); }}
                .format(new Date(System.currentTimeMillis() + off * 1000L));
        int start = -1, end = -1;
        double sum = 0, gmax = 0; double sx = 0, sy = 0;
        int limit = Math.min(t.length(), days * 24 + 24);
        for (int i = 0; i < limit; i++) {
            String ti = t.getString(i);
            if (ti.substring(0, 13).compareTo(nowLocal) < 0) continue;
            double w = ws.optDouble(i, 0), d = wd.optDouble(i, 0);
            boolean ok = day.optInt(i, 0) == 1 && w >= min && w <= max && dirOk(dirs, d);
            if (ok) {
                if (start < 0) { start = i; sum = 0; gmax = 0; sx = 0; sy = 0; }
                end = i; sum += w; gmax = Math.max(gmax, wg.optDouble(i, w));
                sx += Math.sin(Math.toRadians(d)); sy += Math.cos(Math.toRadians(d));
            } else if (start >= 0) {
                if (end - start + 1 >= 2) break;
                start = -1;
            }
        }
        if (start < 0 || end - start + 1 < 2) return null;
        String ts = t.getString(start);
        keyOut[0] = ts.substring(0, 10);
        int n = end - start + 1;
        double avg = sum / n;
        double dir = (Math.toDegrees(Math.atan2(sx, sy)) + 360) % 360;
        Date dd = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(ts.substring(0, 10));
        String dayName = new SimpleDateFormat("EEE", Locale.US).format(dd);
        int h0 = Integer.parseInt(ts.substring(11, 13)), h1 = (Integer.parseInt(t.getString(end).substring(11, 13)) + 1) % 24;
        String unit = unitLabel(cfg);
        return dayName + " " + hourLabel(h0) + "–" + hourLabel(h1) + ": " + wv(cfg, avg) + " " + unit + " " + dir16(dir)
                + ", gusts " + wv(cfg, gmax) + " · rig " + sail(cfg, avg, gmax) + " m²";
    }

    static boolean dirOk(JSONArray dirs, double d) {
        if (dirs == null || dirs.length() == 0) return true;
        int s = (int) Math.round(((d % 360) + 360) % 360 / 45.0) % 8;
        for (int i = 0; i < dirs.length(); i++) if (dirs.optInt(i, -1) == s) return true;
        return false;
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            Class<?> ch = Class.forName("android.app.NotificationChannel");
            Object o = ch.getConstructor(String.class, CharSequence.class, int.class).newInstance(CH, "Wind alerts", 4);
            ch.getMethod("setDescription", String.class).invoke(o, "When your wind conditions are forecast at your spots");
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.getClass().getMethod("createNotificationChannel", ch).invoke(nm, o);
        } catch (Exception e) { }
    }

    static void notify(Context c, int id, String title, String text) {
        ensureChannel(c);
        Notification.Builder b = new Notification.Builder(c);
        if (Build.VERSION.SDK_INT >= 26) {
            try { b.getClass().getMethod("setChannelId", String.class).invoke(b, CH); } catch (Exception e) { }
        }
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(R.drawable.ic_stat)
                .setColor(Color.parseColor("#2EE6C5"))
                .setContentTitle("🌬 " + title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL);
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, b.build());
    }

    static int windColor(double k) {
        double[] v = {0, 5, 8, 11, 14, 17, 20, 23, 27, 31, 36, 42};
        String[] col = {"#9DB4C8", "#4C9BD6", "#2a8fc0", "#2bb3a3", "#3fd17a", "#9fdc3a", "#e3d93a", "#f2b632", "#f07b2e", "#e2483c", "#c2306f", "#9b2fb0"};
        String r = col[0];
        for (int i = 0; i < v.length; i++) if (k >= v[i]) r = col[i];
        return Color.parseColor(r);
    }

    static void updateWidgets(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, WindWidget.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_wind);
        try {
            JSONObject d = new JSONObject(prefs(c).getString("widgetData", "{}"));
            v.setTextViewText(R.id.w_name, d.optString("name", "WindLine"));
            v.setTextViewText(R.id.w_wind, d.optString("wind", "–"));
            v.setTextColor(R.id.w_wind, windColor(d.optDouble("kn", 0)));
            v.setTextViewText(R.id.w_unit, d.optString("unit", "kn"));
            v.setTextViewText(R.id.w_detail, d.optString("detail", "Open WindLine to set up"));
            v.setTextViewText(R.id.w_gear, d.optString("gear", ""));
            long at = d.optLong("at", 0);
            v.setTextViewText(R.id.w_at, at == 0 ? "" : "Updated " + new SimpleDateFormat("h:mm a", Locale.US).format(new Date(at)));
        } catch (Exception e) { }
        Intent open = new Intent(c, MainActivity.class);
        v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 7, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        m.updateAppWidget(ids, v);
    }
}
