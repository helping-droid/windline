package ca.windline.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Runs the background wind check on schedule, and re-arms the schedule after a reboot. */
public class AlertReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context c, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Alerts.schedule(c);
            return;
        }
        final PendingResult pr = goAsync();
        Alerts.runAsync(c.getApplicationContext(), new Runnable() { public void run() { pr.finish(); } });
    }
}
