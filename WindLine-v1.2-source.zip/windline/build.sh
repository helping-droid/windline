#!/bin/bash
# Builds build/WindLine.apk with the Ubuntu Android packages (aapt, dalvik-exchange, apksigner, zipalign).
set -e
cd "$(dirname "$0")"
SDK=/usr/lib/android-sdk/platforms/android-23/android.jar
rm -rf build && mkdir -p build/gen build/classes
aapt package -f -m -J build/gen -M AndroidManifest.xml -S res -I "$SDK"
javac -source 8 -target 8 -bootclasspath "$SDK" -classpath "$SDK" -d build/classes \
  $(find src build/gen -name '*.java') 2>&1 | grep -v -E "JAVA_TOOL|bootstrap|warning" || true
dalvik-exchange --dex --output=build/classes.dex build/classes
aapt package -f -M AndroidManifest.xml -S res -A assets -I "$SDK" -F build/unsigned.apk
(cd build && aapt add unsigned.apk classes.dex >/dev/null)
zipalign -f 4 build/unsigned.apk build/aligned.apk
apksigner sign --ks release.keystore --ks-pass pass:windline123 --key-pass pass:windline123 \
  --out build/WindLine.apk build/aligned.apk
apksigner verify build/WindLine.apk && echo "Built build/WindLine.apk"
